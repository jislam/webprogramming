<HTML>

<HEAD>

<TITLE>An 10 Question IQ Test</TITLE>

</HEAD>

<BODY>

<form action="iq.php" method="post">

Please enter your age now <input type="text" name="age" size="2">

<br /><br />
<ol class="list">
	Below are the 10 questions for this IQ Test. ALL ANSWERS IN LOWERCASE PLEASE.Answer as honestly as you can.

	<br /><br />
	<li>
		Test question 1: What is the approximate shape of orange fruit, it starts with "r". <br/>
		<input type="text" name="T1" size="30">
	</li>
	<br /><br />

	<li>
	Test question 2: What is the product of 5 and 3? <br/><input type="text" name="T2" size="30">
	</li>

	<br /><br />

	<li>
	Test question 3: If I have 3 apples and 12 mangoes, how many fruits do I have?  <br/>
	<input type="text" name="T3" size="30">
	</li>

	<br /><br />

	<li>
	Test question 4: -5 + (+9)-(-8) is how much? <input type="text" name="T4" size="30">
	</li>

	<br /><br />

	<li>
	Test question 5: The result of 2 to the power of 6 divided by eight squared is how much?  <br/>
	<input type="text" name="T5" size="30">
	</li>

	<br /><br />

	<li>
	Test question 6: If I have a right triangle whose two shorter sides are 5 and 12 respectively, how long is the longest side?  <br/>
	<input type="text" name="T6" size="30">
	</li>

	<br /><br />

	<li>
	Test question 7: What is the name of  a  popular TV news network with two “Ns” comprised of 3 letters as initials?  <br/>
	<input type="text" name="T7" size="30">
	</li>

	<br /><br />

	<li>
	Test question 8: In 2008, John is 2 times older than Jerry. In 2040, Jerry will be 46 years old. Find John’s year of birth.  <br/>
	<input type="text" name="T8" size="30">
	</li>

	<br /><br />

	<li>
	Test question 9: If you are using Excel, which function offers the most convenient and most popular
	approach for extracting data from other spreadsheets or workbooks without using the manual copy and paste method
	This is a one word answer. <br/>
	<input type="text" name="T9" size="30">
	</li>

	<br /><br />

	<li>
	Test question 10: If a 65 year old couple retires today how much may they need today to cover their future health care cost?
	This answer is only a figure and does not include a dollar sign.  <br/>
	<input type="text" name="T10" size="30">
	</li>

	<br /><br />
</ol>

<input type="submit" value="Compute my IQ now!">

</form>

</BODY>

</HTML>


